# Spring AI PoC Mastercard Assistant Project

## Project Overview

This project is a Proof of Concept (PoC) for a Mastercard Assistant using Spring AI. The assistant is designed to provide support and enhance productivity through intelligent conversational interactions. by Wipro Mastercard 